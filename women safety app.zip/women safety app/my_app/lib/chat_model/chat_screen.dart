import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:my_app/chat_model/message_text_field.dart';
import 'package:my_app/chat_model/singleMessage.dart';

import '../utils/constants.dart'; // make sure this has progressIndicator()

class ChatScreen extends StatefulWidget {
  final String currentUserId;
  final String friendId;
  final String friendName;

  const ChatScreen({
    Key? key,
    required this.currentUserId,
    required this.friendId,
    required this.friendName,
  }) : super(key: key);

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  String? type;
  String? myName;

  @override
  void initState() {
    super.initState();
    getStatus();
  }

  Future<void> getStatus() async {
    try {
      final doc =
          await FirebaseFirestore.instance
              .collection('users')
              .doc(widget.currentUserId)
              .get();

      setState(() {
        type = doc.data()?['type'];
        myName = doc.data()?['name'];
      });
    } catch (e) {
      Fluttertoast.showToast(msg: "Failed to fetch user data");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.pink,
        title: Text(widget.friendName),
      ),
      body: Column(
        children: [
          Expanded(
            child: StreamBuilder<QuerySnapshot>(
              stream:
                  FirebaseFirestore.instance
                      .collection('users')
                      .doc(widget.currentUserId)
                      .collection('messages')
                      .doc(widget.friendId)
                      .collection('chats')
                      .orderBy('date', descending: false)
                      .snapshots(),
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return progressIndicator(context);
                }

                if (snapshot.hasError) {
                  return Center(child: Text("Something went wrong."));
                }

                if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
                  return Center(
                    child: Text(
                      type == "guardian"
                          ? "TALK WITH CHILD"
                          : "TALK WITH PARENT",
                      style: const TextStyle(fontSize: 24),
                    ),
                  );
                }

                final docs = snapshot.data!.docs;

                return ListView.builder(
                  itemCount: docs.length,
                  itemBuilder: (context, index) {
                    final data = docs[index];
                    final isMe = data['senderId'] == widget.currentUserId;

                    return Dismissible(
                      key: UniqueKey(),
                      onDismissed: (direction) async {
                        await FirebaseFirestore.instance
                            .collection('users')
                            .doc(widget.currentUserId)
                            .collection('messages')
                            .doc(widget.friendId)
                            .collection('chats')
                            .doc(data.id)
                            .delete();

                        await FirebaseFirestore.instance
                            .collection('users')
                            .doc(widget.friendId)
                            .collection('messages')
                            .doc(widget.currentUserId)
                            .collection('chats')
                            .doc(data.id)
                            .delete();

                        Fluttertoast.showToast(
                          msg: 'Message deleted successfully',
                        );
                      },
                      child: SingleMessage(
                        message: data['message'],
                        date: data['date'],
                        isMe: isMe,
                        friendName: widget.friendName,
                        myName: myName ?? '',
                        type: data['type'],
                      ),
                    );
                  },
                );
              },
            ),
          ),
          MessageTextField(
            currentId: widget.currentUserId,
            friendId: widget.friendId,
          ),
        ],
      ),
    );
  }
}
