import 'dart:io';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:geocoding/geocoding.dart';
import 'package:geolocator/geolocator.dart';
import 'package:image_picker/image_picker.dart';
import 'package:uuid/uuid.dart';

class MessageTextField extends StatefulWidget {
  final String currentId;
  final String friendId;

  const MessageTextField({
    super.key,
    required this.currentId,
    required this.friendId,
  });

  @override
  State<MessageTextField> createState() => _MessageTextFieldState();
}

class _MessageTextFieldState extends State<MessageTextField> {
  final TextEditingController _controller = TextEditingController();
  Position? _curentPosition;
  String? _curentAddress;
  File? imageFile;

  Future<void> getImage() async {
    final picker = ImagePicker();
    final pickedFile = await picker.pickImage(source: ImageSource.gallery);
    if (pickedFile != null) {
      setState(() => imageFile = File(pickedFile.path));
      await uploadImage();
    }
  }

  Future<void> getImageFromCamera() async {
    final picker = ImagePicker();
    final pickedFile = await picker.pickImage(source: ImageSource.camera);
    if (pickedFile != null) {
      setState(() => imageFile = File(pickedFile.path));
      await uploadImage();
    }
  }

  Future<void> uploadImage() async {
    if (imageFile == null) return;

    try {
      final fileName = Uuid().v1();
      final ref = FirebaseStorage.instance.ref().child('images/$fileName.jpg');
      final uploadTask = await ref.putFile(imageFile!);
      final imageUrl = await uploadTask.ref.getDownloadURL();
      await sendMessage(imageUrl, 'img');
    } catch (e) {
      Fluttertoast.showToast(msg: 'Image upload failed: $e');
    }
  }

  Future<void> _getCurrentLocation() async {
    LocationPermission permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        Fluttertoast.showToast(msg: "Location permission denied.");
        return;
      } else if (permission == LocationPermission.deniedForever) {
        Fluttertoast.showToast(msg: "Location permission permanently denied.");
        return;
      }
    }

    try {
      final position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high,
      );
      setState(() => _curentPosition = position);
      await _getAddressFromLatLon();
    } catch (e) {
      Fluttertoast.showToast(msg: e.toString());
    }
  }

  Future<void> _getAddressFromLatLon() async {
    if (_curentPosition == null) return;

    try {
      final placemarks = await placemarkFromCoordinates(
        _curentPosition!.latitude,
        _curentPosition!.longitude,
      );
      final place = placemarks[0];
      setState(() {
        _curentAddress =
            "${place.locality}, ${place.postalCode}, ${place.street}";
      });
    } catch (e) {
      Fluttertoast.showToast(msg: e.toString());
    }
  }

  Future<void> sendMessage(String message, String type) async {
    final timestamp = DateTime.now();

    final messageData = {
      'senderId': widget.currentId,
      'receiverId': widget.friendId,
      'message': message,
      'type': type,
      'date': timestamp,
    };

    final senderRef = FirebaseFirestore.instance
        .collection('users')
        .doc(widget.currentId)
        .collection('messages')
        .doc(widget.friendId)
        .collection('chats');

    final receiverRef = FirebaseFirestore.instance
        .collection('users')
        .doc(widget.friendId)
        .collection('messages')
        .doc(widget.currentId)
        .collection('chats');

    await senderRef.add(messageData);
    await receiverRef.add(messageData);
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Container(
        padding: EdgeInsets.zero,
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(10),
        ),
        child: Row(
          children: [
            Expanded(
              child: TextField(
                cursorColor: Colors.pink,
                controller: _controller,
                decoration: InputDecoration(
                  hintText: 'Type your message',
                  fillColor: Colors.grey[100],
                  filled: true,
                  prefixIcon: IconButton(
                    onPressed:
                        () => showModalBottomSheet(
                          backgroundColor: Colors.transparent,
                          context: context,
                          builder: (_) => bottomsheet(),
                        ),
                    icon: Icon(Icons.add_box_rounded, color: Colors.pink),
                  ),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 8.0),
              child: InkWell(
                onTap: () async {
                  final text = _controller.text.trim();
                  if (text.isNotEmpty) {
                    await sendMessage(text, 'text');
                    _controller.clear();
                  }
                },
                child: Icon(Icons.send, color: Colors.pink, size: 30),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget bottomsheet() {
    return Container(
      height: MediaQuery.of(context).size.height * 0.2,
      width: double.infinity,
      child: Card(
        margin: const EdgeInsets.all(18),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            chatsIcon(Icons.location_pin, "Location", () async {
              await _getCurrentLocation();
              await Future.delayed(const Duration(seconds: 2));
              if (_curentPosition != null && _curentAddress != null) {
                final locationMessage =
                    "https://www.google.com/maps/search/?api=1&query=${_curentPosition!.latitude},${_curentPosition!.longitude} ($_curentAddress)";
                await sendMessage(locationMessage, "link");
              }
              Navigator.pop(context);
            }),
            chatsIcon(Icons.camera_alt, "Camera", () async {
              Navigator.pop(context);
              await getImageFromCamera();
            }),
            chatsIcon(Icons.insert_photo, "Photo", () async {
              Navigator.pop(context);
              await getImage();
            }),
          ],
        ),
      ),
    );
  }

  Widget chatsIcon(IconData icon, String title, VoidCallback onTap) {
    return InkWell(
      onTap: onTap,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          CircleAvatar(
            radius: 30,
            backgroundColor: Colors.pink,
            child: Icon(icon, color: Colors.white),
          ),
          const SizedBox(height: 5),
          Text(title, style: TextStyle(fontWeight: FontWeight.w500)),
        ],
      ),
    );
  }
}
