import 'package:cached_network_image/cached_network_image.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

class SingleMessage extends StatelessWidget {
  final String? message;
  final bool? isMe;
  final String? image;
  final String? type;
  final String? friendName;
  final String? myName;
  final Timestamp? date;

  const SingleMessage({
    super.key,
    this.message,
    this.isMe,
    this.image,
    this.type,
    this.friendName,
    this.myName,
    this.date,
  });

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;

    // If date is null, use current time
    final dateTime = date?.toDate() ?? DateTime.now();
    final cdate =
        "${dateTime.hour}:${dateTime.minute.toString().padLeft(2, '0')}";

    final isSender = isMe ?? false;
    final displayName = isSender ? (myName ?? "You") : (friendName ?? "Friend");
    final msg = message ?? "";

    if (type == "text") {
      return Container(
        constraints: BoxConstraints(maxWidth: size.width / 2),
        alignment: isSender ? Alignment.centerRight : Alignment.centerLeft,
        padding: EdgeInsets.all(10),
        child: Container(
          decoration: BoxDecoration(
            color: isSender ? Colors.pink : Colors.black,
            borderRadius:
                isSender
                    ? BorderRadius.only(
                      topLeft: Radius.circular(15),
                      topRight: Radius.circular(15),
                      bottomLeft: Radius.circular(15),
                    )
                    : BorderRadius.only(
                      topLeft: Radius.circular(15),
                      topRight: Radius.circular(15),
                      bottomRight: Radius.circular(15),
                    ),
          ),
          padding: EdgeInsets.all(10),
          alignment: isSender ? Alignment.centerRight : Alignment.centerLeft,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(
                displayName,
                style: TextStyle(fontSize: 15, color: Colors.white70),
              ),
              Divider(),
              Text(msg, style: TextStyle(fontSize: 18, color: Colors.white)),
              Divider(),
              Text(
                cdate,
                style: TextStyle(fontSize: 15, color: Colors.white70),
              ),
            ],
          ),
        ),
      );
    } else if (type == 'img') {
      return Container(
        height: size.height / 2.5,
        width: size.width,
        alignment: isSender ? Alignment.centerRight : Alignment.centerLeft,
        padding: EdgeInsets.all(10),
        child: Container(
          decoration: BoxDecoration(
            color: isSender ? Colors.pink : Colors.black,
            borderRadius:
                isSender
                    ? BorderRadius.only(
                      topLeft: Radius.circular(15),
                      topRight: Radius.circular(15),
                      bottomLeft: Radius.circular(15),
                    )
                    : BorderRadius.only(
                      topLeft: Radius.circular(15),
                      topRight: Radius.circular(15),
                      bottomRight: Radius.circular(15),
                    ),
          ),
          padding: EdgeInsets.all(10),
          alignment: isSender ? Alignment.centerRight : Alignment.centerLeft,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(
                displayName,
                style: TextStyle(fontSize: 15, color: Colors.white70),
              ),
              Divider(),
              CachedNetworkImage(
                imageUrl: msg,
                fit: BoxFit.cover,
                height: size.height / 3.62,
                width: size.width,
                placeholder: (context, url) => CircularProgressIndicator(),
                errorWidget: (context, url, error) => Icon(Icons.error),
              ),
              Divider(),
              Text(
                cdate,
                style: TextStyle(fontSize: 15, color: Colors.white70),
              ),
            ],
          ),
        ),
      );
    } else {
      // Type = link or unknown
      return Container(
        constraints: BoxConstraints(maxWidth: size.width / 2),
        alignment: isSender ? Alignment.centerRight : Alignment.centerLeft,
        padding: EdgeInsets.all(10),
        child: Container(
          decoration: BoxDecoration(
            color: isSender ? Colors.pink : Colors.black,
            borderRadius:
                isSender
                    ? BorderRadius.only(
                      topLeft: Radius.circular(15),
                      topRight: Radius.circular(15),
                      bottomLeft: Radius.circular(15),
                    )
                    : BorderRadius.only(
                      topLeft: Radius.circular(15),
                      topRight: Radius.circular(15),
                      bottomRight: Radius.circular(15),
                    ),
          ),
          padding: EdgeInsets.all(10),
          alignment: isSender ? Alignment.centerRight : Alignment.centerLeft,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(
                displayName,
                style: TextStyle(fontSize: 15, color: Colors.white70),
              ),
              Divider(),
              GestureDetector(
                onTap: () async {
                  final uri = Uri.tryParse(msg);
                  if (uri != null && await canLaunchUrl(uri)) {
                    await launchUrl(uri);
                  }
                },
                child: Text(
                  msg,
                  style: TextStyle(
                    fontStyle: FontStyle.italic,
                    fontSize: 16,
                    color: Colors.white,
                  ),
                ),
              ),
              Divider(),
              Text(
                cdate,
                style: TextStyle(fontSize: 15, color: Colors.white70),
              ),
            ],
          ),
        ),
      );
    }
  }
}
