import 'package:flutter/material.dart';
import 'package:my_app/child/bottom_screen/add_contacts.dart';
import 'package:my_app/child/bottom_screen/chat_page.dart';
import 'package:my_app/child/bottom_screen/contacts_page.dart';
import 'package:my_app/child/bottom_screen/logout.dart';
import 'package:my_app/child/bottom_screen/profile_page.dart';
import 'package:my_app/child/bottom_screen/review_page.dart';
import 'package:my_app/child/bottom_screen/child_home_screen.dart';

class BottomPage extends StatefulWidget {
  const BottomPage({super.key});

  @override
  State<BottomPage> createState() => _BottomPageState();
}

class _BottomPageState extends State<BottomPage> {
  int currentIndex = 0;
  List<Widget> pages = [
    HomeScreen(),
    AddContactsPage(),
    ChatPage(),
    ProfilePage(),
    ReviewPage(),
    Logout(),
  ];
  onTapped(int index) {
    setState(() {
      currentIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: pages[currentIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: currentIndex,
        type: BottomNavigationBarType.fixed,
        onTap: onTapped,
        items: [
          BottomNavigationBarItem(label: 'Home', icon: Icon(Icons.home)),
          BottomNavigationBarItem(
            label: 'Contacts',
            icon: Icon(Icons.contacts),
          ),
          BottomNavigationBarItem(label: 'Chats', icon: Icon(Icons.chat)),
          BottomNavigationBarItem(label: 'Profile', icon: Icon(Icons.person)),
          BottomNavigationBarItem(label: 'Review', icon: Icon(Icons.reviews)),
          BottomNavigationBarItem(label: 'Logout', icon: Icon(Icons.logout)),
        ],
      ),
    );
  }
}
