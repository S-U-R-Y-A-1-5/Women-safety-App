import 'dart:math';

import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:geocoding/geocoding.dart';
import 'package:geolocator/geolocator.dart';
import 'package:permission_handler/permission_handler.dart';

import 'package:my_app/widgets/home_widgets/live_safe.dart';
import 'package:my_app/db/db_services.dart';
import 'package:my_app/model/contactsm.dart';
import 'package:my_app/widgets/home_widgets/CustomCarouel.dart';
import 'package:my_app/widgets/home_widgets/custom_appBar.dart';
import 'package:my_app/widgets/home_widgets/emergency.dart';
import 'package:my_app/widgets/home_widgets/safehome/SafeHome.dart';

class HomeScreen extends StatefulWidget {
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int qIndex = 0;
  Position? _currentPosition;
  String _currentCity = "";
  bool _locationPermissionGranted = false;

  @override
  void initState() {
    super.initState();
    _getPermission();
    _checkLocationPermission();
    getRandomQuote();
  }

  Future<void> _getPermission() async {
    await Permission.sms.request();
  }

  Future<bool> _isPermissionGranted() async {
    return await Permission.sms.isGranted;
  }

  void getRandomQuote() {
    setState(() {
      qIndex = Random().nextInt(6);
    });
  }

  Future<void> _checkLocationPermission() async {
    final status = await Permission.location.request();
    if (status.isGranted) {
      setState(() => _locationPermissionGranted = true);
      _getCurrentLocation();
    } else {
      setState(() => _locationPermissionGranted = false);
    }
  }

  Future<void> _getCurrentLocation() async {
    try {
      Position position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high,
      );
      setState(() {
        _currentPosition = position;
      });
      _getCurrentCity(position);
    } catch (e) {
      Fluttertoast.showToast(msg: 'Error: $e');
    }
  }

  Future<void> _getCurrentCity(Position position) async {
    try {
      List<Placemark> placemarks = await placemarkFromCoordinates(
        position.latitude,
        position.longitude,
      );
      if (placemarks.isNotEmpty) {
        setState(() {
          _currentCity = placemarks.first.locality ?? 'Unknown';
        });
      }
    } catch (e) {
      Fluttertoast.showToast(msg: 'Error fetching city: $e');
    }
  }

  Future<void> getAndSendSms() async {
    if (_currentPosition == null) return;

    List<TContact> contactList = await DatabaseHelper().getContactList();
    String messageBody =
        "I am in trouble. Here's my location: https://maps.google.com/?q=${_currentPosition!.latitude},${_currentPosition!.longitude}";

    if (await _isPermissionGranted()) {
      for (var contact in contactList) {
        // Uncomment this when SMS logic is ready
        // await sendSms(contact.number, messageBody);
      }
    } else {
      Fluttertoast.showToast(msg: "SMS permission not granted");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            children: [
              SizedBox(height: 10),
              CustomAppbar(quoteIndex: qIndex, onTap: getRandomQuote),
              Expanded(
                child: ListView(
                  padding: const EdgeInsets.symmetric(vertical: 10),
                  children: [
                    Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: Colors.grey.shade100,
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Row(
                        children: [
                          CircleAvatar(
                            backgroundColor: Colors.grey.shade300,
                            child: Icon(Icons.location_on),
                          ),
                          const SizedBox(width: 10),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  _locationPermissionGranted
                                      ? "Location Enabled"
                                      : "Location not enabled",
                                  style: TextStyle(fontWeight: FontWeight.bold),
                                ),
                                const SizedBox(height: 5),
                                _currentCity.isEmpty
                                    ? Text(
                                      "Please enable location for better experience.",
                                      maxLines: 2,
                                    )
                                    : Text("Current City: $_currentCity"),
                                if (!_locationPermissionGranted)
                                  Align(
                                    alignment: Alignment.centerLeft,
                                    child: TextButton(
                                      onPressed: _checkLocationPermission,
                                      child: Text("Enable Location"),
                                    ),
                                  ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 15),
                    _buildSectionTitle("In case of emergency dial me"),
                    Emergency(),
                    const SizedBox(height: 10),
                    _buildSectionTitle("Explore your power"),
                    Customcarouel(),
                    const SizedBox(height: 10),
                    _buildSectionTitle("Explore LiveSafe"),
                    LiveSafe(),
                    SafeHome(),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildSectionTitle(String text) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Center(
        child: Text(
          text,
          style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
        ),
      ),
    );
  }
}
