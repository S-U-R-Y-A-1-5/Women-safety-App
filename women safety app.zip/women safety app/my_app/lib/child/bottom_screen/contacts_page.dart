import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:flutter_contacts/flutter_contacts.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:my_app/utils/constants.dart';
import 'package:my_app/db/db_services.dart';
import 'package:my_app/model/contactsm.dart';

class ContactsPage extends StatefulWidget {
  const ContactsPage({Key? key}) : super(key: key);

  @override
  State<ContactsPage> createState() => _ContactsPageState();
}

class _ContactsPageState extends State<ContactsPage> {
  List<Contact> contacts = [];
  List<Contact> contactsFiltered = [];
  final DatabaseHelper _databaseHelper = DatabaseHelper();
  final TextEditingController searchController = TextEditingController();

  @override
  void initState() {
    super.initState();
    requestAndLoadContacts();
  }

  String flattenPhoneNumber(String phoneStr) {
    return phoneStr.replaceAllMapped(RegExp(r'^(\+)|\D'), (Match m) {
      return m[0] == "+" ? "+" : "";
    });
  }

  void filterContact() {
    List<Contact> _contacts = List.from(contacts);
    if (searchController.text.isNotEmpty) {
      _contacts.retainWhere((element) {
        String searchTerm = searchController.text.toLowerCase();
        String searchTermFlatten = flattenPhoneNumber(searchTerm);
        String contactName = element.displayName.toLowerCase();
        bool nameMatch = contactName.contains(searchTerm);
        if (nameMatch) return true;

        if (searchTermFlatten.isEmpty) return false;

        return element.phones.any(
          (p) => flattenPhoneNumber(p.number).contains(searchTermFlatten),
        );
      });
    }
    setState(() {
      contactsFiltered = _contacts;
    });
  }

  Future<void> requestAndLoadContacts() async {
    bool granted = await FlutterContacts.requestPermission();

    if (granted) {
      await getAllContacts();
      searchController.addListener(filterContact);
    } else {
      dialogueBox(context, "Permission denied. Please enable contacts access.");
      if (await Permission.contacts.isPermanentlyDenied) {
        openAppSettings();
      }
    }
  }

  Future<void> getAllContacts() async {
    final _contacts = await FlutterContacts.getContacts(
      withProperties: true,
      withPhoto: true,
    );
    setState(() {
      contacts = _contacts;
    });
  }

  @override
  Widget build(BuildContext context) {
    bool isSearching = searchController.text.isNotEmpty;
    bool listItemExists =
        isSearching ? contactsFiltered.isNotEmpty : contacts.isNotEmpty;

    return Scaffold(
      appBar: AppBar(title: Text('Contacts'), backgroundColor: kColorRed),
      body:
          contacts.isEmpty
              ? Center(child: CircularProgressIndicator())
              : SafeArea(
                child: Column(
                  children: [
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: TextField(
                        controller: searchController,
                        decoration: InputDecoration(
                          labelText: "Search contact",
                          prefixIcon: Icon(Icons.search),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                        ),
                      ),
                    ),
                    listItemExists
                        ? Expanded(
                          child: ListView.builder(
                            itemCount:
                                isSearching
                                    ? contactsFiltered.length
                                    : contacts.length,
                            itemBuilder: (context, index) {
                              final contact =
                                  isSearching
                                      ? contactsFiltered[index]
                                      : contacts[index];

                              return ListTile(
                                title: Text(contact.displayName),
                                leading:
                                    (contact.photo != null)
                                        ? CircleAvatar(
                                          backgroundImage: MemoryImage(
                                            contact.photo!,
                                          ),
                                          backgroundColor: kColorRed,
                                        )
                                        : CircleAvatar(
                                          backgroundColor: kColorRed,
                                          child: Text(
                                            getInitials(contact.displayName),
                                            style: const TextStyle(
                                              color: Colors.white,
                                              fontWeight: FontWeight.bold,
                                            ),
                                          ),
                                        ),
                                onTap: () {
                                  if (contact.phones.isNotEmpty) {
                                    final phoneNum = contact.phones[0].number;
                                    final name = contact.displayName;
                                    _addContact(TContact(phoneNum, name));
                                  } else {
                                    Fluttertoast.showToast(
                                      msg: "Oops! No phone number found.",
                                    );
                                  }
                                },
                              );
                            },
                          ),
                        )
                        : const Center(child: Text("No contacts found.")),
                  ],
                ),
              ),
    );
  }

  void _addContact(TContact newContact) async {
    int result = await _databaseHelper.insertContact(newContact);
    if (result != 0) {
      Fluttertoast.showToast(msg: "Contact added successfully");
    } else {
      Fluttertoast.showToast(msg: "Failed to add contact");
    }
    Navigator.of(context).pop(true);
  }

  String getInitials(String name) {
    List<String> names = name.trim().split(' ');
    String initials = '';
    for (var part in names) {
      if (part.isNotEmpty) {
        initials += part[0];
      }
    }
    return initials.toUpperCase();
  }
}
