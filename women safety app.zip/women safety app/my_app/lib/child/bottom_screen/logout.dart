import 'package:flutter/material.dart';
import 'package:my_app/child/child_login_screen.dart';
import 'package:my_app/components/PrimaryButton.dart'; // Make sure this is the correct import path
// Replace with actual path to your login screen

class Logout extends StatelessWidget {
  const Logout({super.key});

  void goTo(BuildContext context, Widget screen) {
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (context) => screen),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(18.0),
          child: PrimaryButton(
            title: 'Logout',
            onPressed: () {
              goTo(context, LoginScreen());
            },
          ),
        ),
      ),
    );
  }
}
