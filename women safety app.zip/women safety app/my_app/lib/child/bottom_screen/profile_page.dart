import 'dart:io';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:image_picker/image_picker.dart';
import 'package:my_app/child/bottom_page.dart';
import 'package:my_app/child/child_login_screen.dart';
import 'package:my_app/components/PrimaryButton.dart';
import 'package:my_app/components/custom_textfield.dart';
import 'package:my_app/utils/constants.dart';
import 'package:uuid/uuid.dart';

class CheckUserStatusBeforeChatOnProfile extends StatelessWidget {
  const CheckUserStatusBeforeChatOnProfile({super.key});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<User?>(
      stream: FirebaseAuth.instance.authStateChanges(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator());
        } else {
          if (snapshot.hasData) {
            return ProfilePage();
          } else {
            Fluttertoast.showToast(msg: 'Please login first');
            return LoginScreen();
          }
        }
      },
    );
  }
}

class ProfilePage extends StatefulWidget {
  const ProfilePage({super.key});

  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  final TextEditingController nameC = TextEditingController();
  final TextEditingController guardianEmailC = TextEditingController();
  final TextEditingController childEmailC = TextEditingController();
  final TextEditingController phoneC = TextEditingController();

  final key = GlobalKey<FormState>();

  String? id;
  String? profilePic;
  String? downloadUrl;
  bool isSaving = false;

  @override
  void initState() {
    super.initState();
    getData();
  }

  @override
  void dispose() {
    nameC.dispose();
    guardianEmailC.dispose();
    childEmailC.dispose();
    phoneC.dispose();
    super.dispose();
  }

  Future<void> getData() async {
    try {
      final querySnapshot =
          await FirebaseFirestore.instance
              .collection('users')
              .where('id', isEqualTo: FirebaseAuth.instance.currentUser!.uid)
              .get();

      if (querySnapshot.docs.isNotEmpty) {
        final data = querySnapshot.docs.first.data();
        setState(() {
          nameC.text = data['name'] ?? '';
          childEmailC.text = data['childEmail'] ?? '';
          guardianEmailC.text = data['guardianEmail'] ?? '';
          phoneC.text = data['phone'] ?? '';
          id = querySnapshot.docs.first.id;
          profilePic = data['profilePic'];
        });
      }
    } catch (e) {
      Fluttertoast.showToast(msg: 'Failed to load user data: $e');
    }
  }

  Future<String?> uploadImage(String filePath) async {
    try {
      final fileName = Uuid().v4();
      final Reference fbStorage = FirebaseStorage.instance
          .ref('profile')
          .child(fileName);
      final UploadTask uploadTask = fbStorage.putFile(File(filePath));
      await uploadTask;
      downloadUrl = await fbStorage.getDownloadURL();
      return downloadUrl;
    } catch (e) {
      Fluttertoast.showToast(msg: e.toString());
      return null;
    }
  }

  Future<void> update() async {
    setState(() {
      isSaving = true;
    });

    String? uploadedUrl =
        profilePic != null && !profilePic!.startsWith('http')
            ? await uploadImage(profilePic!)
            : profilePic;

    if (uploadedUrl == null) {
      Fluttertoast.showToast(msg: 'Failed to upload image.');
      setState(() {
        isSaving = false;
      });
      return;
    }

    Map<String, dynamic> data = {
      'name': nameC.text.trim(),
      'profilePic': uploadedUrl,
    };

    try {
      await FirebaseFirestore.instance
          .collection('users')
          .doc(FirebaseAuth.instance.currentUser!.uid)
          .update(data);

      setState(() {
        isSaving = false;
      });

      Fluttertoast.showToast(msg: 'Profile updated successfully');
      goTo(context, const BottomPage());
    } catch (e) {
      Fluttertoast.showToast(msg: 'Failed to update profile: $e');
      setState(() {
        isSaving = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(),
      body:
          isSaving
              ? const Center(
                child: CircularProgressIndicator(backgroundColor: Colors.pink),
              )
              : SafeArea(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.all(18.0),
                  child: Center(
                    child: Form(
                      key: key,
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const Text(
                            "UPDATE YOUR PROFILE",
                            style: TextStyle(fontSize: 25),
                          ),
                          const SizedBox(height: 15),
                          GestureDetector(
                            onTap: () async {
                              final XFile? pickedImage = await ImagePicker()
                                  .pickImage(
                                    source: ImageSource.gallery,
                                    imageQuality: 50,
                                  );
                              if (pickedImage != null) {
                                setState(() {
                                  profilePic = pickedImage.path;
                                });
                              }
                            },
                            child:
                                profilePic == null
                                    ? CircleAvatar(
                                      backgroundColor: Colors.deepPurple,
                                      radius: 80,
                                      child: Center(
                                        child: Image.asset(
                                          'assets/add_pic.png',
                                          height: 80,
                                          width: 80,
                                        ),
                                      ),
                                    )
                                    : profilePic!.startsWith('http')
                                    ? CircleAvatar(
                                      backgroundColor: Colors.deepPurple,
                                      radius: 80,
                                      backgroundImage: NetworkImage(
                                        profilePic!,
                                      ),
                                    )
                                    : CircleAvatar(
                                      backgroundColor: Colors.deepPurple,
                                      radius: 80,
                                      backgroundImage: FileImage(
                                        File(profilePic!),
                                      ),
                                    ),
                          ),
                          const SizedBox(height: 15),
                          CustomTextField(
                            controller: nameC,
                            hintText: 'Enter your name',
                            validate: (v) {
                              if (v == null || v.trim().isEmpty) {
                                return 'Please enter your updated name';
                              }
                              return null;
                            },
                          ),
                          const SizedBox(height: 10),
                          CustomTextField(
                            controller: childEmailC,
                            hintText: "Child Email",
                            readOnly: true,
                            validate: (v) {
                              if (v == null || v.trim().isEmpty) {
                                return 'Child email cannot be empty';
                              }
                              return null;
                            },
                          ),
                          const SizedBox(height: 10),
                          CustomTextField(
                            controller: guardianEmailC,
                            hintText: "Guardian Email",
                            readOnly: true,
                            validate: (v) {
                              if (v == null || v.trim().isEmpty) {
                                return 'Guardian email cannot be empty';
                              }
                              return null;
                            },
                          ),
                          const SizedBox(height: 10),
                          CustomTextField(
                            controller: phoneC,
                            hintText: "Phone Number",
                            readOnly: true,
                            validate: (v) {
                              if (v == null || v.trim().isEmpty) {
                                return 'Phone number cannot be empty';
                              }
                              return null;
                            },
                          ),
                          const SizedBox(height: 25),
                          PrimaryButton(
                            title: "UPDATE",
                            onPressed: () async {
                              if (key.currentState!.validate()) {
                                SystemChannels.textInput.invokeMethod(
                                  'TextInput.hide',
                                );
                                if (profilePic == null) {
                                  Fluttertoast.showToast(
                                    msg: 'Please select a profile picture',
                                  );
                                  return;
                                }
                                await update();
                              }
                            },
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
    );
  }
}

// Example goTo function for navigation (replace with your own logic)
void goTo(BuildContext context, Widget page) {
  Navigator.pushReplacement(
    context,
    MaterialPageRoute(builder: (context) => page),
  );
}
