class UserModel {
  String? name;
  String? id;
  String? phone;
  String? password;
  String? childEmail;
  String? guardianEmail;
  String? type;
  UserModel({
    this.name,
    this.id,
    this.phone,
    this.childEmail,
    this.guardianEmail,
    this.type,
    this.password,
  });

  Map<String, dynamic> toJson() => {
    'name': name,
    'id': id,
    'phone': phone,
    'password': password,
    'childEmail': childEmail,
    'guardianEmail': guardianEmail,
    'type': type,
  };
}
