import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:my_app/chat_model/chat_screen.dart';
import 'package:my_app/child/child_login_screen.dart';
import 'package:my_app/utils/constants.dart'; // should contain `goTo` and `dialogueBox`

class ParentHomeScreen extends StatelessWidget {
  const ParentHomeScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final currentUserEmail = FirebaseAuth.instance.currentUser?.email;

    return Scaffold(
      drawer: Drawer(
        child: Column(
          children: [
            const DrawerHeader(child: Icon(Icons.person, size: 80)),
            ListTile(
              leading: const Icon(Icons.logout),
              title: const Text("SIGN OUT"),
              onTap: () async {
                try {
                  await FirebaseAuth.instance.signOut();
                  goTo(
                    context,
                    LoginScreen(),
                  ); // Replace with actual login screen
                } catch (e) {
                  dialogueBox(context, "Error: ${e.toString()}");
                }
              },
            ),
          ],
        ),
      ),
      appBar: AppBar(
        backgroundColor: Colors.pink,
        title: const Text("SELECT CHILD"),
      ),
      body:
          currentUserEmail == null
              ? const Center(child: Text("User not logged in"))
              : StreamBuilder<QuerySnapshot>(
                stream:
                    FirebaseFirestore.instance
                        .collection('users')
                        .where('type', isEqualTo: 'child')
                        .where('guardianEmail', isEqualTo: currentUserEmail)
                        .snapshots(),
                builder: (context, snapshot) {
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return Center(child: progressIndicator(context));
                  }

                  if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
                    return const Center(child: Text("No children found."));
                  }

                  final children = snapshot.data!.docs;

                  return ListView.builder(
                    itemCount: children.length,
                    itemBuilder: (context, index) {
                      final child = children[index];
                      return Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Card(
                          color: const Color.fromARGB(255, 250, 163, 192),
                          child: ListTile(
                            title: Text(child['name']),
                            onTap: () {
                              goTo(
                                context,
                                ChatScreen(
                                  currentUserId:
                                      FirebaseAuth.instance.currentUser!.uid,
                                  friendId: child.id,
                                  friendName: child['name'],
                                ),
                              );
                            },
                          ),
                        ),
                      );
                    },
                  );
                },
              ),
    );
  }
}
