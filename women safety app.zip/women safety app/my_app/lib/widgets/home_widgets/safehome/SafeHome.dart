import 'package:background_sms/background_sms.dart';
import 'package:flutter/material.dart';
import 'package:flutter_contacts/flutter_contacts.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:geocoding/geocoding.dart';
import 'package:geolocator/geolocator.dart';
import 'package:my_app/components/PrimaryButton.dart';
import 'package:my_app/db/db_services.dart';
import 'package:my_app/model/contactsm.dart';
import 'package:permission_handler/permission_handler.dart';

class SafeHome extends StatefulWidget {
  @override
  State<SafeHome> createState() => _SafeHomeState();
}

class _SafeHomeState extends State<SafeHome> {
  Position? _currentPosition;
  String? _currentAddress;
  LocationPermission? permission;

  Future<void> _getPermission() async {
    await [Permission.sms, Permission.locationWhenInUse].request();
  }

  Future<bool> _isPermissionGranted() async {
    return await Permission.sms.isGranted;
  }

  Future<void> _sendSms(
    String phoneNumber,
    String message, {
    int simSlot = 1,
  }) async {
    SmsStatus result = await BackgroundSms.sendMessage(
      phoneNumber: phoneNumber,
      message: message,
      simSlot: simSlot,
    );

    if (result == SmsStatus.sent) {
      Fluttertoast.showToast(msg: "Message sent to $phoneNumber");
    } else {
      Fluttertoast.showToast(msg: "Failed to send SMS to $phoneNumber");
    }
  }

  Future<void> _getCurrentLocation() async {
    permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        Fluttertoast.showToast(msg: "Location permission denied");
        return;
      } else if (permission == LocationPermission.deniedForever) {
        Fluttertoast.showToast(msg: "Location permission permanently denied");
        return;
      }
    }

    try {
      Position position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high,
      );
      setState(() {
        _currentPosition = position;
      });
      _getAddressFromLatLon();
    } catch (e) {
      Fluttertoast.showToast(msg: e.toString());
    }
  }

  Future<void> _getAddressFromLatLon() async {
    try {
      if (_currentPosition == null) return;
      List<Placemark> placemarks = await placemarkFromCoordinates(
        _currentPosition!.latitude,
        _currentPosition!.longitude,
      );
      Placemark place = placemarks[0];
      setState(() {
        _currentAddress =
            "${place.locality}, ${place.postalCode}, ${place.street}";
      });
    } catch (e) {
      Fluttertoast.showToast(msg: e.toString());
    }
  }

  @override
  void initState() {
    super.initState();
    _getPermission();
    _getCurrentLocation();
  }

  void showModelSafeHome(BuildContext context) {
    showModalBottomSheet(
      context: context,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) {
        return Container(
          height: MediaQuery.of(context).size.height * 0.7,
          padding: const EdgeInsets.all(14.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                "Send your current location immediately to your emergency contact list",
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              SizedBox(height: 10),
              if (_currentAddress != null)
                Text(
                  _currentAddress!,
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 16),
                ),
              SizedBox(height: 10),
              PrimaryButton(
                title: "GET LOCATION",
                onPressed: _getCurrentLocation,
              ),
              SizedBox(height: 10),
              PrimaryButton(
                title: "SET ALERT",
                onPressed: () async {
                  List<TContact> contactList =
                      await DatabaseHelper().getContactList();
                  if (_currentPosition == null || _currentAddress == null) {
                    Fluttertoast.showToast(msg: "Location not available");
                    return;
                  }

                  String messageBody =
                      "I am in trouble. Please reach me at: https://www.google.com/maps/search/?api=1&query=${_currentPosition!.latitude},${_currentPosition!.longitude}. Address: $_currentAddress";

                  if (await _isPermissionGranted()) {
                    for (TContact contact in contactList) {
                      _sendSms(contact.number, messageBody);
                    }
                  } else {
                    Fluttertoast.showToast(msg: "SMS permission not granted");
                  }
                },
              ),
            ],
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () => showModelSafeHome(context),
      child: Card(
        elevation: 5,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        child: Container(
          height: 180,
          width: MediaQuery.of(context).size.width * 0.7,
          padding: EdgeInsets.all(12),
          child: Row(
            children: [
              Expanded(
                child: ListTile(
                  title: Text('Send Location'),
                  subtitle: Text(
                    'Share your live location with emergency contacts',
                  ),
                ),
              ),
              ClipRRect(
                borderRadius: BorderRadius.circular(20),
                child: Image.asset(
                  'assets/route.jpg',
                  height: 100,
                  width: 100,
                  fit: BoxFit.cover,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
